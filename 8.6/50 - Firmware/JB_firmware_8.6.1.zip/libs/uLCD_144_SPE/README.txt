uLCD_144 Arduino Library
Copyright (c) 2011 Valery Miftakhov.  All right reserved.

This is a small library of the most useful (for me anyway) 
functions to drive a SGC version of the uLCD_144 screen
(http://www.sparkfun.com/products/10090 at ~$30).

In order to use, you have to copy uLCD_144 folder into your 
Arduino Libraries folder (found in your arduino software
installation folder). You then have to import a uLCD_144 
library from your sketch (by selecting the library
from Sketch->Import Library menu drop-down. 

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

See attached example for using display in your sketch. Have fun.
